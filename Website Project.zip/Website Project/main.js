// Quiz program
//global variables
let score = 0
let quest1 = document.getElementById("question-1")
let quest2 = document.getElementById("question-2")
let quest3 = document.getElementById("question-3")
let quest4 = document.getElementById("question-4")
let quest5 = document.getElementById("question-5")

//mark quiz
document.getElementById("mark-button").addEventListener("click", markQuiz);

function markQuiz () {
    score = 0
    //mark question 1
    if (document.getElementById("answer-1").value == "d") {
        score ++
        quest1.classList.add("correct")
        quest1.classList.remove("incorrect")
    } else {
        quest1.classList.add("incorrect")
        quest1.classList.remove("correct")
    }
    //mark question 2
    if (document.getElementById("answer-2").value == "d") {
        score ++
        quest2.classList.add("correct")
        quest2.classList.remove("incorrect")
    } else {
        quest2.classList.add("incorrect")
        quest2.classList.remove("correct")
    }
    //mark question 3
    if (document.getElementById("answer-3").value == "a") {
        score ++
        quest3.classList.add("correct")
        quest3.classList.remove("incorrect")
    } else {
        quest3.classList.add("incorrect")
        quest3.classList.remove("correct")
    }
    //mark question 4
    if (document.getElementById("answer-4").value == "c") {
        score ++
        quest4.classList.add("correct")
        quest4.classList.remove("incorrect")
    } else {
        quest4.classList.add("incorrect")
        quest4.classList.remove("correct")
    }
    //mark question 5
    if (document.getElementById("answer-5").value == "b") {
        score ++
        quest5.classList.add("correct")
        quest5.classList.remove("incorrect")
    } else {
        quest5.classList.add("incorrect")
        quest5.classList.remove("correct")
    }
    //display score
    document.getElementById('score-display').innerHTML = score
}

//Reset Quiz

document.getElementById("reset-button").addEventListener("click", resetQuiz)

function resetQuiz () {
    //reset score
    document.getElementById('score-display').innerHTML = "-"
    //reset question 1
    document.getElementById("answer-1").value = ""
    quest1.classList.remove("correct")
    quest1.classList.remove("incorrect")
    //reset question 2
    document.getElementById("answer-2").value = ""
    quest2.classList.remove("correct")
    quest2.classList.remove("incorrect")
    //reset question 3
    document.getElementById("answer-3").value = ""
    quest3.classList.remove("correct")
    quest3.classList.remove("incorrect")
    //reset question 4
    document.getElementById("answer-4").value = ""
    quest4.classList.remove("correct")
    quest4.classList.remove("incorrect")
    //reset question 5
    document.getElementById("answer-5").value = ""
    quest5.classList.remove("correct")
    quest5.classList.remove("incorrect")
}